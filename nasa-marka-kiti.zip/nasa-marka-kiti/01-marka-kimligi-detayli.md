# NASA Marka Kimliği — Detaylı Rehber

Kaynak: NASA Graphics Standards Manual'dan derlenen NASA Brand Guidelines (14 CFR 1221 yetkisiyle yayımlanır).

---

## 1. Marka mimarisi

| Katman | Unsur | Rolü |
|---|---|---|
| Ana kimlik | **Amblem (Insignia, "Meatball")** | Kurumun resmî kimliği. Tüm yayın, sergi, görsel iletişim ve tabelalarda zorunlu. |
| Destekleyici | **Logotip (Logotype, "Worm")** | Büyük ve cesur uygulamalarda ek grafik. Amblemsiz kullanılmaz (ticari ürünler hariç). |
| Kısıtlı | **Yönetici Mührü (Seal)** | Sadece NASA Yöneticisi'nin resmî yazışma ve etkinliklerinde. |
| Tanımlayıcı | **Identifier** | Kurum adı + amblem + web adresinden oluşan resmî yerleşim düzeni. |
| Alt markalar | Görev/proje/program tanımlayıcıları, mürettebat armaları, kampanya ve yıl dönümü logoları | Amblemin yerini almaz, onun yanında ikincil kalır. |
| Özel | **Principal Identifier** | Şu an yalnızca Artemis ve James Webb Uzay Teleskobu. |
| Özel | **Data Insignia ("DATA AT WORK")** | NASA verisi kullanan dış ürünler için, ön onayla. |
| Özel | **Grantee Insignia** | Aktif hibe/işbirliği anlaşması olanlar için, sınırlı kullanım. |

---

## 2. Amblem (Meatball)

**Tarihçe:** 1959'da NASA çalışanı James Modarelli tasarladı. 1976–1992 arasında kullanımdan kaldırıldı, 1992'de geri döndü ve bugünkü resmî kimlik oldu.

**Sembolizm:**

- Küre → bir gezegen
- Yıldızlar → uzay
- Yörünge → uzay yolculuğu
- Kırmızı vektör (kanat biçimli ok) → havacılık

**Sürümler (4):**

1. Tam renkli
2. Tek renkli
3. Beyaz çizgili tek renkli
4. Beyaz çizgili mono

Üretim koşulu, medya kalitesi ve görünürlüğe göre en uygun olanı seçilir.

**Tam renkli amblem kuralları:**

- Asla beyaz çizgiyle (white rule) gösterilmez.
- PANTONE, CMYK veya RGB formülleriyle basılabilir.
- Ters (negatif) gösterilemez.

**Arka plan:**

- Tercih: düz beyaz, siyah, gri veya gümüş (PMS 877).
- Kontrast korunursa renkli zemin, tam renkli fotoğraf veya sanat eseri üzerinde de olabilir.
- Çatışan renklerde veya benzer doygunluktaki zeminlerde kullanılmaz.

**Koruma alanı:** Kürenin kenarından itibaren en az **1N** (amblemdeki "N" harfinin yüksekliği). Metin ve görsel bu alana giremez.

**Ortalama:** Amblem simetrik değildir. **Mavi küreye göre** ortalanır (sphere-centered), nesnenin bütününe göre değil (object-centered = yanlış).

**İhlaller (örnek):** Döndürmek, oranını bozmak, renk değiştirmek, efekt/gölge eklemek, öğeleri yeniden düzenlemek, karmaşık zeminde kullanmak. Liste kapsamlı değildir.

---

## 3. Renk paleti

| Renk | HEX | RGB | CMYK | PMS |
|---|---|---|---|---|
| **NASA Blue** | `#0032A0` | 0 50 160 | 100/80/0/12 | 286 |
| **NASA Red** | `#E4002B` | 228 0 43 | 0/100/100/0 | 185 |
| Gümüş (zemin) | — | — | — | 877 |
| Beyaz | `#FFFFFF` | 255 255 255 | 0/0/0/0 | — |
| Siyah | `#000000` | 0 0 0 | 0/0/0/100 | — |

Worm logotipi: NASA Red, beyaz, siyah ya da çok açık zemin üzerinde. Siyah/koyu/orta tonda zeminde kırmızı olarak ve hiçbir zaman NASA Blue olarak gösterilmez (İletişim Müdürlüğü izni hariç).

---

## 4. Tipografi

### Basılı

| Yazı tipi | Kullanım |
|---|---|
| **Helvetica** | Tüm kullanımlar. Identifier ve web adresi için **zorunlu**. |
| **Garamond** | Tüm kullanımlar için önerilen serif. |

### Dijital / web — Horizon Design System (HDS)

| Yazı tipi | Rol | Neden |
|---|---|---|
| **Inter** (variable) | Büyük display ve başlıklar | Ekran için tasarlanmış, yüksek x-height |
| **Public Sans** | Gövde metni | Nötr ama karakterli, uzun metinde okunaklı |
| **DM Mono** | Büyük rakamlar, küçük etiketler | Teknik görünüm, rakam okunurluğu |

Üçü de Google Fonts'ta ücretsiz.

### Ek kurallar

- "National Aeronautics and Space Administration" ve "NASA" her zaman sade bir sans-serif ile yazılır.
- Dekoratif veya fantezi fontlar kullanılmaz.
- Amblemdeki yazıyı ya da Worm'u andıran yazı stilleri yasaktır.

---

## 5. Identifier (tanımlayıcı) düzenleri

**Tercih edilen:** Amblem (koruma alanıyla) tasarım çerçevesinin **sağ üst köşesine**, kurum adı **sol kenara** hizalanır. Metin tek satırdır; ayraç ve üç katlı broşür gibi dar alanlarda iki satıra bölünebilir. Tüm düzenlerin dış kenarlarında en az **2N** boşluk.

**Alternatif (sağa/sola yaslı):**

- Kurum adı "and" kelimesinden sonra bölünür:
  National Aeronautics and / Space Administration
- Satır aralığı, kurum adının punto değerinden 2 punto fazladır.
- Kurum adı ile amblem arasında dikey ayraç çizgisi bulunur.
- Alt satırın x-height'ı, amblemdeki "NASA" yazısının taban çizgisiyle hizalanır.
- Sola yaslı düzende ayraç ile amblem arasında **1.5N** boşluk.

---

## 6. Logotip (Worm)

- 1975'te Richard Danne ve Bruce Blackburn tasarladı. 1976–1992 arasında resmî logoydu.
- Bugün amblemin yanında ek grafik olarak, büyük ve cesur uygulamalarda kullanılır.
- Ticari ürünler dışında amblem yakında olmadan kullanılmaz.
- Her kullanımı İletişim Müdürlüğü ve/veya merchandising ekibi inceler.
- Renkler ve zeminler için 3. bölüme bakın. Kendi koruma alanı vardır.

---

## 7. Destekleyici unsurlar

- **Yönetici Mührü:** Sadece Yönetici'nin resmî yazışma, etkinlik ve faaliyetleri. Ürünlerde kullanılmaz, amblemle birlikte kullanılmaz. Kurum tanımlayıcısı olarak sadece NASA bayrakları ve güvenlik kartlarında yer alır.
- **Mürettebat / görev armaları:** 1965'ten beri var. Yama, kıyafet, rozet ve çıkartmalarda kullanılır. Yayınlarda (onaylı basın kitleri hariç) ve amblemin yanında yer almaz.
- **Görev / proje / program tanımlayıcıları:** Ekip morali ve iletişim için. Amblemin yerini almaz. İç kullanımda serbesttir, dış kullanımı İletişim Müdürlüğü değerlendirir. Kamu malı değildir.
- **Principal Identifiers:** Sona erme tarihi olan büyük görevler için. Amblem görsel önceliğini korur. Şu an yalnızca Artemis ve JWST.
- **Kampanya / yıl dönümü logoları:** Tarihî dönüm noktaları için. Dış kullanımı İletişim Müdürlüğü değerlendirir.

---

## 8. Data Insignia ("DATA AT WORK")

- NASA amblemi + altında "DATA AT WORK" ibaresi. Tam renkli veya siyah-beyaz.
- Her yanda en az **1N** boşluk. Başka markalarla birlikte kullanılırsa kontrast kenarlıklı bir kutu içine alınır.
- Tek parça olarak kullanılır, değiştirilemez.
- **Uygunluk:** Kamuya açık NASA verisi, modeli, algoritması, API'si veya aracını kullanan uygulama, site, sergi ve sunumlar.
- **Ön onay zorunlu.** Resmî dosyalar onaydan sonra NASA'dan gelir.
- **Yasal uyarı metni** (basın materyali, sergi ve konferans gibi kamuya açık kullanımlarda zorunlu):

  > This material includes data, models, or resources provided by the National Aeronautics and Space Administration (NASA). Any findings, interpretations, or conclusions presented do not necessarily reflect the views of NASA.

- **Yasak:** Ticari reklam veya bağış toplama, promosyon, lobi ve siyasi mesajlar, NASA çalışanlarının adı veya görüntüsü, süresi dolmuş ortaklık ima etmek, NASA verisini esaslı biçimde kullanmayan ürünler, NASA sponsorluğu veya onayı ima etmek.

---

## 9. Genel kısıtlamalar

- Amblem, logo, mühür ve tanımlayıcılar kamu malı değildir ve kanunla korunur (14 CFR 1221, 1958 NASA Uzay Yasası).
- Üçüncü taraf site veya materyallerde marka unsuru, reklam, ticari görünüm ya da promosyon amacıyla kullanılmaz.
- NASA çalışanı olmayanlar veya NASA'nın desteklemediği ürünler açık izin olmadan kullanamaz.
- Bir dış kuruluşu, programı veya kişiyi onaylıyormuş izlenimi verecek şekilde kullanılmaz.
- Armalar ve tanımlayıcılar NASA amblemini veya Worm'u, yüklenici adını veya logosunu, amblem ya da Worm yazısını andıran tipografiyi içeremez.
- Uluslararası ajans veya ortak sponsor logoları ancak önceden onayla kullanılabilir.
- NASA materyalleri NFT'lerde kullanılamaz.

**İletişim:** agency-brand@mail.nasa.gov
