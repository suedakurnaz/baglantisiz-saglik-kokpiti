# Resmî Kaynaklar ve Görseller

Aşağıdaki görseller NASA'nın yönerge sayfasında yer alıyor. Sadece kuralları göstermek için
referans amaçlı. Kendi işinizde logo dosyası olarak kullanılamazlar.

## Sayfalar

- Marka yönergeleri: https://www.nasa.gov/nasa-brand-center/brand-guidelines/
- Marka merkezi: https://www.nasa.gov/nasa-brand-center/
- Data Insignia (başvuru formu ve PDF kılavuz): https://www.nasa.gov/nasa-data-insignia/
- Görsel ve medya kullanımı: https://www.nasa.gov/nasa-brand-center/images-and-media/
- Reklam yönergeleri: https://www.nasa.gov/nasa-brand-center/advertising-guidelines/
- Ürün (merchandise) onayları: https://www.nasa.gov/nasa-brand-center/merchandise-approvals/

## Yönerge görselleri

| Konu | Bağlantı |
|---|---|
| Amblem öğeleri | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-elements-1.png |
| Amblem sürümleri | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-versions2024.png |
| Renk rehberi | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-colorguide.png |
| Arka plan renkleri | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-backgroundcolor-1.png |
| Koruma alanı / min. boyut | https://www.nasa.gov/wp-content/uploads/2023/11/nasa-insignia-clearspaceminimumrequirements.png |
| Küreye göre ortalama (doğru) | https://www.nasa.gov/wp-content/uploads/2023/07/insignia-spherecentered.svg |
| Nesneye göre ortalama (yanlış) | https://www.nasa.gov/wp-content/uploads/2023/07/insignia-objectcentered.svg |
| İhlaller | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-violations-rgb.png |
| Identifier, tek satır, sola yaslı | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-lockup-singleline-left.png |
| Identifier, iki satır, sağa yaslı | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-lockup-2line-right.png |
| Identifier, iki satır, sola yaslı | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-insignia-lockup-2line-left.png |
| Worm örneği | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-wormbus.jpg |
| Worm koruma alanı | https://www.nasa.gov/wp-content/uploads/2023/07/nasa-logotype-protectedspace.png |

## Fontlar (ücretsiz, Google Fonts)

- Inter: https://fonts.google.com/specimen/Inter
- Public Sans: https://fonts.google.com/specimen/Public+Sans
- DM Mono: https://fonts.google.com/specimen/DM+Mono
