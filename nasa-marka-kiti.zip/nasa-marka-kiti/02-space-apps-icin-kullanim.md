# Space Apps Projesinde NASA Markası

NASA Space Apps Challenge'a katılmak, NASA amblemini (Meatball) ya da Worm'u projede kullanma izni vermez.
Proje NASA'nın resmî ürünü sayılmaz. Amblemi koymak NASA onayı ima eder ve bu, yönergelerde açıkça yasaklanıyor.

> Space Apps'in kendi katılımcı kurallarını ve marka dosyalarını da kontrol edin (spaceappschallenge.org).
> Yarışma, katılımcıların kullanabileceği kendi logolarını sağlıyor.

## Yapabilecekleriniz

- **Metinle atıf vermek:** "Built with NASA open data", "NASA Space Apps Challenge 2026 için geliştirildi" gibi.
  Kurum adı sade bir sans-serif (Inter, Helvetica) ile yazılır.
- **Kullandığınız veri setlerini kaynak olarak listelemek:** Earthdata, NASA Open Data Portal, PDS, API adları vb.
- **Yasal uyarıyı eklemek:**
  > This material includes data, models, or resources provided by the National Aeronautics and Space Administration (NASA). Any findings, interpretations, or conclusions presented do not necessarily reflect the views of NASA.
- **Space Apps'in kendi logosunu**, onların kurallarına uyarak kullanmak.
- **NASA'ya benzemeyen ama uzay temalı bir görsel dil kurmak.** Kendi renklerinizi ve fontlarınızı seçebilirsiniz.
  Inter, Public Sans ve DM Mono açık lisanslı fontlar, kullanmanızda sorun yok.

## Yapmamanız gerekenler

- Uygulama, site, sunum veya posterde Meatball, Worm ya da mühür kullanmak.
- Logoyu yeniden çizmek, taklit etmek ya da ona benzeyen bir logo yapmak.
- "NASA uygulaması", "NASA onaylı", "NASA ile ortak" gibi ifadeler.
- NASA amblemini ya da Worm'u andıran tipografi.

## Logoyu meşru şekilde kullanmak isterseniz

**NASA Data Insignia ("DATA AT WORK")** tam bu amaç için var: NASA verisi kullanan dış ürünler.

1. nasa.gov/nasa-data-insignia sayfasındaki talep formunu doldurun.
2. Onay gelirse NASA resmî dosyaları, şablonları ve uygulama kılavuzunu gönderir.
3. Gelen dosyaları bu kitteki `logolar/` klasörüne koyun ve kurallara uyun
   (1N boşluk, değiştirmemek, kamuya açık kullanımda yasal uyarı).

Not: Data Insignia da promosyon ve ticari reklamda kullanılamaz.

Sorular için: agency-brand@mail.nasa.gov
