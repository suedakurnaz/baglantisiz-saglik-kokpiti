# NASA Marka Kimliği — Referans Kiti

> Gayriresmî özet. Kaynak: NASA Brand Center (nasa.gov/nasa-brand-center/brand-guidelines) ve
> NASA Data Insignia sayfası, Kasım 2026'da okundu. Bağlayıcı olan her zaman NASA'nın kendi yönergeleridir.

## İçerik

| Dosya | Ne işe yarar |
|---|---|
| `marka-kimligi.html` | Tarayıcıda açılan görsel marka rehberi (renk örnekleri, tipografi, kurallar) |
| `01-marka-kimligi-detayli.md` | Tüm kuralların detaylı metin hâli |
| `02-space-apps-icin-kullanim.md` | Space Apps projesinde logo konusunda ne yapılır / yapılmaz |
| `03-resmi-dosyalar-ve-linkler.md` | Resmî görsellerin ve başvuru formlarının bağlantıları |
| `tokens/renkler.json` | Renk değerleri (HEX/RGB/CMYK/PMS) |
| `tokens/nasa-tokens.css` | CSS değişkenleri + font tanımları |
| `logolar/` | Resmî logo dosyaları için ayrılmış klasör (bkz. aşağıdaki not) |

## Logo dosyaları hakkında

Logolar bu pakette yok. İki sebebi var:

1. NASA amblemi (Meatball), Worm logotipi ve mühür 14 CFR 1221 ile korunuyor, kamu malı değil.
   Açık izin olmadan kullanılamıyor, kopyalanamıyor ya da yeniden çizilemiyor.
2. Space Apps projelerinde ürüne NASA logosu koymak NASA onayı ima ettiği için uygun değil.
   Doğru yol `02-space-apps-icin-kullanim.md` dosyasında anlatılıyor.

İzin alındığında NASA resmî dosyaları doğrudan gönderiyor. Onları `logolar/` klasörüne koyabilirsiniz.

İletişim: agency-brand@mail.nasa.gov
